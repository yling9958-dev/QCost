| Dataset | Points | Build_s | Mean_ms | P95_ms | P99_ms | QPS | PeakMemory_MiB | Correctness | BuildRank | SizeRank | MeanRank | P95Rank | P99Rank | QPSRank | MemoryRank | Top1Count | Size_MiB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| GeoLife | 181000000 | N/A | N/A | N/A | N/A | N/A | 11340.3 | NOT_RUN | N/A/4 | N/A/3 | N/A/4 | N/A/4 | N/A/4 | N/A/4 | N/A/4 | 0 | N/A |

| Dataset | BuildRank | SizeRank | MeanRank | P95Rank | P99Rank | QPSRank | MemoryRank | Top1Count |
|---|---|---|---|---|---|---|---|---|
| GeoLife | N/A/4 | N/A/3 | N/A/4 | N/A/4 | N/A/4 | N/A/4 | N/A/4 | 0 |


GeoLife

| Method | Build(s) | Size(MiB) | Mean(ms) | P95(ms) | P99(ms) | QPS | PeakMem(MiB) | Correctness | Status |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|
| QMF-Index | N/A | N/A | N/A | N/A | N/A | N/A | 11340.3 | NOT_RUN | RESOURCE_BLOCKED_MEMORY |
| PostGIS GiST | 1389.09 | 9868.2 | N/A | N/A | N/A | N/A | 216.93 | 1000/1000 exact | BUILD_FAILED |
| LISA | 83.774 | N/A | 54.144 | 21.886 | 348.321 | 18.4693 | 7903.09 | 1000/1000 exact | PASS |
| Flood | 99.7026 | N/A | N/A | N/A | N/A | N/A | 20343.9 | NOT_RUN | RESOURCE_BLOCKED_MEMORY |
| Tsunami | 34.3669 | 4142.76 | 59.9498 | 95.8028 | 639.179 | 16.6806 | 7718.75 | 1000/1000 exact | PASS |
| LMSFC | 60.9454 | 4833.22 | 124.113 | 1163.32 | 1938.14 | 8.05714 | 8322.88 | 1000/1000 exact | PASS |
| BMTree | 3965.3 | 4865.59 | 29.4109 | 15.5341 | 162.442 | 34.001 | 17012.6 | 1000/1000 exact | PASS |
| Boost R*-tree | N/A | N/A | N/A | N/A | N/A | N/A | 22616.2 | NOT_RUN | BUILD_FAILED |
