"""Downstream numeric reporting. Never starts workers or edits benchmark checkpoints."""
import csv
import math
from pathlib import Path
import statistics
import support as s

DISPLAY=['QMF-Index','PostGIS GiST','LISA','Flood','Tsunami','LMSFC','BMTree','Boost R*-tree']
SHORT=['geolife','gowalla','nyc_taxi','skewed_2d']
NAMES=['GeoLife','Gowalla','NYC Taxi','Skewed 2D']
FIELDS=['Method',*s.METRICS,'Correctness','Status']

def text(path,value):
    import os
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.part')
    with temp.open('w') as f:
        f.write(value); f.flush(); os.fsync(f.fileno())
    temp.replace(path)

def fmt(v):
    if v is None or v=='': return 'N/A'
    if isinstance(v,float): return f'{v:.6g}' if math.isfinite(v) else 'N/A'
    return str(v)

def rows(dataset):
    result=[]
    for label,(display,runtime) in zip(DISPLAY,s.METHODS):
        cp=s.marker(dataset,runtime+'_method')
        r=s.read_json(cp)['payload'] if cp.exists() else {}
        r={**{m:None for m in s.METRICS},'Correctness':'NOT_RUN','Status':'NOT_RUN',**r,'Method':label}
        corr=s.marker(dataset,runtime+'_correctness')
        if corr.exists():
            v=s.read_json(corr)['payload']; r['Missing']=v.get('missing'); r['Extra']=v.get('extra')
        else:
            r['Missing']=r['Extra']=None
            if r['Status']=='CORRECTNESS_INVALID': r['Correctness']='INVALID'
        result.append(r)
    return result

def ranks(data):
    result=[]
    for metric in s.METRICS:
        eligible=[(i,r[metric]) for i,r in enumerate(data) if r['Status']=='PASS' and r.get(metric) is not None
                  and (metric!='IndexSize_MiB' or s.METHODS[i][1] in s.PERSISTENT)]
        v=data[0].get(metric)
        rank=None
        if any(i==0 for i,_ in eligible):
            rank=1+sum((x>v if metric=='QPS' else x<v) for i,x in eligible)
        result.append({'Metric':metric,'QMFRank':rank,'Denominator':len(eligible)})
    return result

def table(data):
    labels=['Method','Build(s)','Size(MiB)','Mean(ms)','P95(ms)','P99(ms)','QPS','PeakMem(MiB)','Correctness','Status']
    return '| '+' | '.join(labels)+' |\n|'+ '|'.join(['---']+['---:']*7+['---','---'])+'|\n'+''.join(
        '| '+' | '.join(fmt(r.get(k)) for k in FIELDS)+' |\n' for r in data)

def dataset_report(row,index):
    dataset=row['dataset_id']; data=rows(dataset); ranking=ranks(data)
    root=s.OUT/SHORT[index]; prefix=SHORT[index].upper()
    primary=root/(prefix+'_8_METHODS_7_METRICS.csv'); md=primary.with_suffix('.md')
    rankfile=root/(prefix+'_QMF_RANKING.csv')
    s.atomic_csv(primary,[{k:(r.get(k) if r.get(k) is not None else 'N/A') for k in FIELDS} for r in data],FIELDS)
    s.atomic_csv(rankfile,ranking,['Metric','QMFRank','Denominator'])
    q=data[0]; top=sum(v['QMFRank']==1 for v in ranking)
    body=f'{NAMES[index].upper()} FINAL RESULT\n{row["record_count"]:,} POINTS\n\n'+table(data)
    body+='\nQMF-INDEX — '+NAMES[index]+'\n\n'+''.join(f'{k} = {fmt(q.get(k))}\n\n' for k in [*s.METRICS,'Correctness','Missing','Extra'])
    body+='Ranks:\n\n'+''.join(f'{v["Metric"]} = {fmt(v["QMFRank"])}/{v["Denominator"]}\n\n' for v in ranking)
    body+=f'QMF TOP-1 COUNT = {top} / 7\n\n'
    for metric in ['Mean_ms','P95_ms','P99_ms','QPS']:
        eligible=[r for r in data[1:] if r['Status']=='PASS' and r.get(metric) is not None]
        best=(max if metric=='QPS' else min)(eligible,key=lambda r:r[metric]) if eligible else None
        body+=f'Best competing method for {metric} = {best["Method"] if best else "N/A"}\n\n'
    body+='Build repetitions = 1. Only correctness-valid methods enter rankings. Missing measurements are N/A.\n\nQMF_ALGORITHM_CHANGED = NO\n'
    text(md,body)
    files=[primary,md,rankfile,s.OUT/'02_queries'/dataset/'query_manifest.json',s.OUT/'01_dataset_inventory'/f'{dataset}.json']
    manifest=root/(prefix+'_RESULT_MANIFEST.sha256')
    text(manifest,''.join(s.sha(p)+'  '+str(p)+'\n' for p in files))
    print(body,flush=True)
    return [*files,manifest]

def aggregate(inventory):
    summaries=[]; allrows=[]; rankrows=[]; comparisons=[]
    for i,row in enumerate(inventory):
        if not s.marker(row['dataset_id'],'results_persisted').exists(): continue
        data=rows(row['dataset_id']); rank=ranks(data); q=data[0]
        summary={'Dataset':NAMES[i],'Points':row['record_count'],**{k:q.get(k) for k in s.METRICS},'Correctness':q['Correctness']}
        for key,v in zip(['BuildRank','SizeRank','MeanRank','P95Rank','P99Rank','QPSRank','MemoryRank'],rank):
            summary[key]=f'{fmt(v["QMFRank"])}/{v["Denominator"]}'
        summary['Top1Count']=sum(v['QMFRank']==1 for v in rank)
        summary['Size_MiB']=summary.pop('IndexSize_MiB'); summaries.append(summary)
        rankrows.append({'Dataset':NAMES[i],**{k:summary[k] for k in ['BuildRank','SizeRank','MeanRank','P95Rank','P99Rank','QPSRank','MemoryRank','Top1Count']}})
        for r in data:
            allrows.append({'Dataset':NAMES[i],**{k:r.get(k) for k in [*FIELDS,'Missing','Extra']}})
        for metric in ['Mean_ms','P95_ms','P99_ms','QPS']:
            eligible=[r for r in data[1:] if r['Status']=='PASS' and r.get(metric) is not None]
            best=(max if metric=='QPS' else min)(eligible,key=lambda r:r[metric]) if eligible else None
            improvement=None
            if best and q['Status']=='PASS' and best[metric]:
                improvement=100*((q[metric]-best[metric]) if metric=='QPS' else (best[metric]-q[metric]))/best[metric]
            comparisons.append({'Dataset':NAMES[i],'Metric':metric,'QMF':q.get(metric),'BestBaselineMethod':best['Method'] if best else None,
                'BestBaselineValue':best[metric] if best else None,'QMFRelativeImprovementPercent':improvement,
                'QMFRank':rank[s.METRICS.index(metric)]['QMFRank']})
    if not summaries: return
    s.atomic_csv(s.OUT/'QMF_CROSS_DATASET_SUMMARY.csv',summaries)
    s.atomic_csv(s.OUT/'QMF_RANKS.csv',rankrows)
    s.atomic_csv(s.OUT/'ALL_DATASETS_ALL_METHODS_7_METRICS.csv',allrows)
    s.atomic_csv(s.OUT/'QMF_VS_BEST_BASELINE.csv',comparisons)
    def mdtable(values):
        fields=list(values[0]); return '| '+' | '.join(fields)+' |\n|'+'|'.join(['---']*len(fields))+'|\n'+''.join('| '+' | '.join(fmt(r.get(k)) for k in fields)+' |\n' for r in values)
    body=mdtable(summaries)+'\n'+mdtable(rankrows)+'\n'
    for i,row in enumerate(inventory):
        if s.marker(row['dataset_id'],'results_persisted').exists(): body+='\n'+NAMES[i]+'\n\n'+table(rows(row['dataset_id']))
    text(s.OUT/'QMF_CROSS_DATASET_SUMMARY.md',body)
    text(s.ROOT/'FOUR_DATASET_PAPER_METRICS_20260911.md',body)
